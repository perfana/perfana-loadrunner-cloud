	
	Call_many()
{
	web_rest("Call_many",
		"URL=https://demo-optimus-prime-fe.perfana.io/remote/call-many?count=3&path=delay",
		"Method=GET",
		"Snapshot=t530962.inf",
		LAST);

		return 0;
}
