Database_call()
{
	web_rest("Database_call",
		"URL=https://demo-optimus-prime-fe.perfana.io/remote/call-many?count=1&path=/db/employee/find-by-name?firstName=${first_name}",
		"Method=GET",
		"Snapshot=t530962.inf",
		LAST);
	return 0;
}
